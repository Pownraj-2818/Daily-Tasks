import React from "react";
import {
  Alert,
  Button,
  Image,
  Platform,
  StatusBar,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
} from "react-native";
import {
  useDimensions,
  useDeviceOrientation,
} from "@react-native-community/hooks";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import AppText from './components/AppText'

export default function App() {
  return (
      <View style={styles.container1}>
      <AppText string='Welcome pownraj'></AppText>
      </View>
  );
}

const styles = StyleSheet.create({
  container1: {
    flex:1,
    backgroundColor: "black",
    alignItems: "center",
    justifyContent: "center",
  
  },
});
