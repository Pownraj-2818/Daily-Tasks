import React from 'react'
import { StyleSheet, Text, View } from 'react-native'
import styles from './styles'

export default function AppText(props) {
    return (
        <View>
            <Text style={styles.android}>{props.string}</Text>
        </View>
    )
}


