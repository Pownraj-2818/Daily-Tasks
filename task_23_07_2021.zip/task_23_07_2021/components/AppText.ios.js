import React from 'react'
import { StyleSheet, Text, View } from 'react-native'
import styles from './styles'

export default function AppText(props) {
    return (
        <View>
            <Text style={styles.ios}>{props.string}</Text>
        </View>
    )
}


